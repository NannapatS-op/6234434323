/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;

/**
 *
 * @author oplabtop
 */
public class BusTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Object> arr = new ArrayList<>();
        Hybrid a = new Hybrid (45,1200000,600,150,1);
        arr.add(a);
        CNGBus b = new CNGBus (50,100000,3,2);
        arr.add(b);
        for (Object bus : arr){        
            System.out.println("ID: " + ((Bus)bus).getID());
            if (bus instanceof Hybrid){
                System.out.println("Emission Tier: " + ((Hybrid)bus).getEmissionTier());
                System.out.println("Accel: " + ((Hybrid)bus).getAccel());
            }
            else if (bus instanceof CNGBus){
                System.out.println("Emission Tier: " + ((CNGBus)bus).getEmissionTier());
                System.out.println("Accel: " + ((CNGBus)bus).getAccel());
            }     
        }
    }
    
    
}
