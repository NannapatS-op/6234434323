/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author oplabtop
 */
public class MusicBox implements SimpleQueue {
    private ArrayList<String> musicName;  
    public MusicBox(){
        musicName = new ArrayList<>();
    }
    @Override
    public void enqueue(Object o) {        
        musicName.add((String)o);
        System.out.println((String)o+" is added in queue");        
    }

    @Override
    public void dequeue() {              
        System.out.println("Now playing "+ musicName.get(0));
        musicName.remove(0);
    }
}
