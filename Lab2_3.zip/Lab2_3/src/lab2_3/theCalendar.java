/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author oplabtop
 */
public class theCalendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar birthDay = new GregorianCalendar(2001,Calendar.APRIL,2);
        cal.add(Calendar.DAY_OF_MONTH,100);
        birthDay.add(Calendar.DAY_OF_MONTH,10000);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        int dayBD = birthDay.get(Calendar.DAY_OF_MONTH);
        int monthBD = birthDay.get(Calendar.MONTH);
        int yearBD = birthDay.get(Calendar.YEAR);
        int weekdayBD = birthDay.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+day+" "+month+" "+year);
        System.out.println(weekdayBD+" "+dayBD+" "+monthBD+" "+yearBD);
       
        
    }
    
}
