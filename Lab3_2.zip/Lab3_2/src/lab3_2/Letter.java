/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author oplabtop
 */
public class Letter {
    private String line,from,to;
    public Letter(String from,String to){
        this.from = from;
        this.to = to;
        line = "\n";
                
    }
    public void addLine(String line){
        this.line = this.line+line+"\n";
        
    }
    public String getText(){
        String text = "Dear "+to+"\n"+line+"\nSincerely,\n\n"+from;
        return text;
    }
}    

