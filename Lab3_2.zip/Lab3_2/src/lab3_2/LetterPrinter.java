/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author oplabtop
 */
public class LetterPrinter {
    public static void main(String[] args){
        Letter printer = new Letter("Clarissa","Jade");
        printer.addLine("We must find Simon quickly.");
        printer.addLine("He might be in danger.");
        System.out.println(printer.getText());
    }  
    
}
