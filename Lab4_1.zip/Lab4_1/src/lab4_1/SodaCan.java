/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author oplabtop
 */
public class SodaCan {
    
    private double height, diameter;

    public SodaCan(double h,double d){
        height = h;
        diameter = d;
        
    }
    
    public double getVolume(){
        double volume = Math.PI*Math.pow((diameter/2), 2)*height;
        return volume;
                
    }
    
    public double getSurfaceArea(){
        double surface = 2*Math.PI*Math.pow((diameter/2), 2)+(2*Math.PI*(diameter/2)*height);
        return surface;
    }
    
}
