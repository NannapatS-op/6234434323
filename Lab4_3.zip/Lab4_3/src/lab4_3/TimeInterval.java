/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author oplabtop
 */
public class TimeInterval {

    private int startTime,endTime;
    
    public TimeInterval(int startTime,int endTime){
        this.endTime = endTime;
        this.startTime = startTime;
    }
    
    public int getHours(){
        int hours = endTime-startTime;
        hours = hours/100;
        return hours;
    }
    
    public int getminute(){
        int minute = (endTime/100*60+endTime%100)-(startTime/100*60+startTime%100);
        minute = minute%60;
        return minute;
    }
    
}
