/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

import java.util.Scanner;

/**
 *
 * @author oplabtop
 */
public class TimeIntervalTester {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int startTime = sc.nextInt();
        System.out.print("Enter end time: ");
        int endTime = sc.nextInt();
        TimeInterval t = new TimeInterval(startTime,endTime);
        System.out.print(t.getHours()+" hours ");
        System.out.println(t.getminute()+" minutes");
    }
    
}
