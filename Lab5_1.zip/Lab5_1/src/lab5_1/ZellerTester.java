/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

import java.util.Scanner;

/**
 *
 * @author oplabtop
 */
public class ZellerTester {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter year (e.g. 2012): ");
        int year = sc.nextInt();
        System.out.print("Enter month (1-12): ");
        int month = sc.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int dayOfMonth = sc.nextInt();
        if (month == 1){month = 13;year--;}
        if (month == 2){month = 14;year--;}
        Zeller demo = new Zeller(year,month,dayOfMonth);
        System.out.println("Day of the week is "+demo.getDayOfWeek().getDay());
        
    }
    
}
