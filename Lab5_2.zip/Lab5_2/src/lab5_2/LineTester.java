/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;

/**
 *
 * @author oplabtop
 */
public class LineTester {
    
    public static void main(String[] args){
        Line l1 = new Line(0.44,3.4);
        Line l2 = new Line(32,32,9);
        System.out.println("Are the two lines equals?: "+l1.equals(l2));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        
        if (l1.isIntersect(l2)){
            Point2D point = l1.getIntersectionPoint(l2);
            System.out.print("Point of intersection: ");
            System.out.printf("%.2f", point.getX());
            System.out.print(", ");
            System.out.printf("%.2f", point.getY());
            System.out.println();
        }
    }
    
}
