/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author oplabtop
 */
public class Cannonball {

    private double initV;
    private double simS;
    private double simT;
    public static final double g = 9.81;
    
    public Cannonball(double initV){
        this.initV = initV;
    }
    
    public void simulatedFlight(){
        double v = initV;
        for(int sec = 1;sec<=10;sec++ ){
            for(int i=1;i<=100;i++){
                simS += v*0.01;
                v = v - g*0.01;
            }
            simT = sec;
            System.out.printf("\nDistance on %d sec: %.3f%n", sec,simS);
        }
        simT += v/g;
        simS += (v/2)*v/g;
        System.out.printf("\nFinal distance: %.3f", simS);
        System.out.printf(" Total time: %.1f%n",simT);
    }
    public double calculusFlight(double t){
        double s = initV*t - 0.5*g*t*t;
        return s;
    }
    public double getSimulatedDistance(){
        return simS;
    }
    public double getSimulatedTime(){
        return simT;
    }
    
}
