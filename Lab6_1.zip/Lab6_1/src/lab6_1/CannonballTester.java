/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author oplabtop
 */
public class CannonballTester {
    public static void main(String[] args){
        Cannonball ball = new Cannonball(100);
        ball.simulatedFlight();
        System.out.printf("\nDistance from calculus equation: %.3f",ball.calculusFlight(ball.getSimulatedTime()));
    }
}
