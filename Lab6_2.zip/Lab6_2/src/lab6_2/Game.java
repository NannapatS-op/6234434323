/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author oplabtop
 */
public class Game {

    public void play(){
        int userScore = 0;
        int comScore = 0;
        int result = 0;
        while(result != 2){
            Random generator = new Random();
            int computerInt = generator.nextInt(3); 
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS:");
            Scanner sc = new Scanner(System.in);
            String input = sc.next();
            while(!"0".equals(input) & !"1".equals(input) & !"2".equals(input)){
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS:");
                input = sc.next();
            }
            int inputInt = Integer.parseInt(input);
            switch (inputInt) {
                case 0:System.out.println("You enter: ROCK");break;
                case 1:System.out.println("You enter: PAPER");break;
                case 2:System.out.println("You enter: SCISSORS");break;
                default:break;
            }
            switch (computerInt) {
                case 0:System.out.println("Computer: ROCK");break;
                case 1:System.out.println("Computer: PAPER");break;
                case 2:System.out.println("Computer: SCISSORS");break;
                default:break;
            }
 
            if(inputInt == computerInt){
                System.out.println("It's a tie.");
            }
            else if(inputInt == 0){
                if(computerInt == 1){
                    System.out.println("You lose!");
                    comScore = comScore + 1;
                }
                else if (computerInt == 2){
                    System.out.println("You win!");
                    userScore = userScore + 1;
                }
            }
            else if(inputInt == 1){
                if(computerInt == 2){
                    System.out.println("You lose!");
                    comScore = comScore + 1;
                }
                else if (computerInt == 0){
                    System.out.println("You win!");
                    userScore = userScore + 1;
                }
            }
            else if(inputInt == 2){
                if(computerInt == 0){
                    System.out.println("You lose!");
                    comScore = comScore + 1;
                }
                else if (computerInt == 1){
                    System.out.println("You win!");
                    userScore = userScore + 1;
                }
            }            
            if(comScore >= userScore) result = comScore - userScore;
            else result = userScore - comScore;
            result = (comScore >= userScore)? comScore - userScore:userScore- comScore;
        }
        if(comScore > userScore){
            System.out.println("-----------------\nToo bad! You lose.");
        }
        else System.out.println("-----------------\nCongrats! You win.");
        System.out.println("User Score: "+userScore);
        System.out.println("Computer Score: "+comScore);
    }
}
