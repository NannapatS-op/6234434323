/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

import java.util.Random;

/**
 *
 * @author oplabtop
 */
public class CityGrid {

    private int xCoor,yCoor,gridSize;
    public CityGrid(int size){
        this.gridSize = size;
        xCoor = size/2;
        yCoor = size/2;
    }
    public void walk(){
        Random r = new Random();
        int walk = r.nextInt(4);
        switch(walk){
            case 0 : xCoor++;break;
            case 1 : xCoor--;break;
            case 2 : yCoor++;break;
            case 3 : yCoor--;break;
        }
    }
    public void reset(){
        xCoor = gridSize/2;
        yCoor = gridSize/2;
    }
    public boolean isInCity(){
        if ((xCoor<0 || xCoor>gridSize) || (yCoor<0 || yCoor>gridSize)){
            return false;
        }
        else{
            return true;
        }
    }
    
}
