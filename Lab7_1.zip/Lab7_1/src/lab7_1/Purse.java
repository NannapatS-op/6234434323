/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;

/**
 *
 * @author oplabtop
 */
public class Purse {
    
    ArrayList<String> purse = new ArrayList<>();
    private int nickle,dime,quarter;
    
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    
   
   
    public String toString(){
        /*String s = "";
        for(int i = 0;i<purse.size();i++){
            s += purse.get(i)+" ";
        }
        return "Purse ["+s+"]";*/
        
        String s = "Purse";
        return s+ purse.toString();
                
    }
    
    public ArrayList<String> reverse(){
        ArrayList<String> Reverse = new ArrayList<>();
        int j = 0;
        for(int i = purse.size()-1; i>= 0;i--){
            String coin = purse.get(i);
            Reverse.add(j,coin);j++;
        }
        purse = Reverse;
        return purse;
        
    }
    
    public void transfer(Purse other){
        int preSize = purse.size();
        for(int i = 0;i<preSize;i++){
            other.addCoin(purse.get(0));
            purse.remove(0);
        }
    }
    
    public boolean sameContents(Purse other){
        int match = 0;
        for( int i =0;i < purse.size();i++){
            if(purse.get(i).equals(other.purse.get(i))){
                match++;
            }
        }
        return match == purse.size();
    }
    
    public boolean sameCoins(Purse other){
        
        for(int i = 0;i<purse.size();i++){
            switch(purse.get(i)){
                case "Nickle" : this.nickle +=1;
                case "Dime" : this.dime +=1;
                case "Quarter" : this.quarter += 1;
            }
        }
        for (int i = 0;i<other.purse.size();i++){
            switch (other.purse.get(i)){
                case "Nickle" : other.nickle +=1;
                case "Dime" : other.dime +=1;
                case "Quarter" : other.quarter += 1;
            }
        }
        return this.nickle == other.nickle && this.dime == other.dime && this.quarter == other.quarter;
        
    }    
}
