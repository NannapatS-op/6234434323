/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author oplabtop
 */
public class PurseTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Purse a = new Purse();
        a.addCoin("Quarter");
        a.addCoin("Dime");
        a.addCoin("Nickle");
        a.addCoin("Dime");
        System.out.println("purse_A addCoin: "+a.toString());
                
        Purse b = new Purse();
        b.addCoin("Dime");
        b.addCoin("Nickle");
        b.addCoin("Dime");
        b.addCoin("Quarter");
        System.out.println("purse_B addCoin: "+b.toString());
        
        System.out.println("sameContents? : "+a.sameContents(b));
        
        a.reverse();
        System.out.println("purse_A reverse: "+a.toString());
        
        System.out.println("sameCoins?: "+a.sameCoins(b));
        
        a.transfer(b);
        System.out.println("Transfer: (purse_A) "+a.toString()+"\n\t  (purse_B) "+b.toString());
        
        
        
        
        
        
        
        
        
    }
    
}
