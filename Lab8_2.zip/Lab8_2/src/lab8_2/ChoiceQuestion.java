/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

import java.util.ArrayList;

/**
 *
 * @author oplabtop
 */
public class ChoiceQuestion extends Question {
    private ArrayList<String> choices;
    public ChoiceQuestion(String text) {
        super(text);
        choices = new ArrayList();
    }
    public void addChoice(String choice,boolean correct){
        choices.add(choice);
        if(correct) setAnswer(choice);
    }
    public void display(){
        System.out.println(getText());
        for(int i = 0; i< choices.size();i++){
            int num =i+1;
            System.out.println(num+": "+choices.get(i));
        }
    }
    @Override
    public boolean checkAnswer(String response){
        int numChoice = Integer.parseInt(response)-1;
        return choices.get(numChoice).equals(getAnswer());
    }
}
