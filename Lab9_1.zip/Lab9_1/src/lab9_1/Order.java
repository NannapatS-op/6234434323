/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

import java.util.ArrayList;

/**
 *
 * @author oplabtop
 */
public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    public Order(Customer c){
        cntOrder++;
        this.id = cntOrder;
        this.c = c;       
        p = new ArrayList<>();
    }
    
    public void addPizza(Pizza order){
        p.add(order);
    }
    
    public String getOrderDetail(){
        System.out.println("Order id : "+id);
        System.out.println(c.toString());
        for (int i = 0; i < p.size();i++){
            System.out.println(p.get(i).toString());
        }
        return "Total pieces : "+p.size()+"\nTotal cost : "+calculatePayment();                
    }
    
    public double calculatePayment(){  
        double payment = 0;
        for (int i = 0; i < p.size();i++){
            payment +=  p.get(i).getPrice();
        } 
        if (c instanceof GoldCustomer){
            return payment - ((((GoldCustomer)c).getDiscount()/100)*payment);
        } 
        else return payment;     
    }

    
}
