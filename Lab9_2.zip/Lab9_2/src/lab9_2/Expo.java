/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author oplabtop
 */
public class Expo extends Taylor {
    public Expo(int k, double x){    
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public double getApprox(){
        double approx = 0;
        for (int n = 0 ; n <= getIter() ;n++){
            approx += Math.pow(getValue(), n)/factorial(n);
        }            
        return approx;
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is "+ Math.exp(getValue())+ ".\nApproximated value is "+getApprox()+".");       
    }
    
}
