/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author oplabtop
 */
public class Sine extends Taylor {
    public Sine(int k, double x){    
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public double getApprox(){
        double approx = 0;
        for(int n = 0 ; n <= getIter() ;n++){           
            approx += (Math.pow(-1,n)*Math.pow(getValue(),2*n+1))/factorial(2*n+1);
        }            
        return approx;
    }
    
    @Override
    public void printValue(){
        System.out.println("Value from Math.sine() is "+ Math.sin(getValue())+".\nApproximated value is "+getApprox()+".");
    }
}
